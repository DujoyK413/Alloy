
const Page2 = () => {
    return (
        <div>
            <h2 className="text-5xl text-center">2</h2>
        </div>
    );
};

export default Page2;