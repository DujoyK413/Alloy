
const CourseProgress = () => {
    return (
        <div>
            <h2>Course Progress</h2>
        </div>
    );
};

export default CourseProgress;