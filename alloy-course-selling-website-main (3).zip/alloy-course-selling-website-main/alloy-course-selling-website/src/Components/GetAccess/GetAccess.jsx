
const GetAccess = () => {
    return (
        <div>
            <div>
                <button className="text-sm bg-slate-400 p-2 rounded-lg hover:bg-green-600">Get Access</button>
            </div>
        </div>
    );
};

export default GetAccess;